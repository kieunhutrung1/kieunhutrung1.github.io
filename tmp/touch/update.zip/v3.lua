----------------------------------------------------------------
-- TikTok AutoFollow – gõ từng ký tự
----------------------------------------------------------------
local imgPath      = rootDir() .. "/img/"
local usernameFile = rootDir() .. "/username.txt"
local bundleID     = "com.ss.iphone.ugc.Ame"

----------------------------------------------------------------
-- Hàm tiện ích
----------------------------------------------------------------
local function tap(x, y)
    if not (x and y) then return false end
    touchDown(1, x, y); usleep(100000)
    touchUp  (1, x, y); usleep(500000)
    return true
end

-- Vuốt từ phải ➡ trái (For You → Explore) – giữ nguyên
local function swipeToExplore()
    touchDown(5, 262.76, 750.80); usleep(50124)
    touchMove(5, 281.23, 757.93); usleep(16546)
    touchMove(5, 294.57, 757.93); usleep(16744)
    touchMove(5, 309.96, 758.94); usleep(16592)
    touchMove(5, 341.79, 759.98); usleep(16704)
    touchMove(5, 374.63, 761.00); usleep(16717)
    touchMove(5, 414.67, 761.00); usleep(16573)
    touchMove(5, 463.93, 761.00); usleep(16677)
    touchMove(5, 512.17, 761.00); usleep(16794)
    touchMove(5, 563.48, 761.00); usleep(16612)
    touchMove(5, 616.86, 761.00); usleep(14997)
    touchUp  (5, 620.97, 764.05); usleep(1000000)
end

-- Tìm ảnh → {x,y} hoặc nil
local function findTemplate(name, threshold)
    threshold = threshold or 0.88
    local r = findImage(imgPath .. name, 1, threshold, nil, false, 2)
    if r and #r > 0 then return r[1][1], r[1][2] end
    return nil
end

-- Chờ tới khi tìm thấy ảnh (retry)
local function waitTemplate(name, threshold, retries, delay)
    retries = retries or 15         -- tối đa ~ 6 giây
    delay   = delay   or 400000     -- 0.4 s/lần
    for _ = 1, retries do
        local x, y = findTemplate(name, threshold)
        if x then return x, y end
        usleep(delay)
    end
    return nil
end

-- Tap ảnh (1 lần), có thông báo lỗi
local function tapTemplate(name, threshold)
    local x, y = findTemplate(name, threshold)
    if x then tap(x, y); return {x, y} end
    toast("❌ Không thấy " .. name); return nil
end

-- Gõ username, search, mở trang cá nhân
local function openProfile(username)
    -- 1. Vuốt sang Explore (3 lần đầu)
    for _ = 1, 3 do swipeToExplore() end

    -- 2. Chờ nút kính lúp; nếu không thấy thì vuốt thêm 1 lần rồi thử lại
    local sx, sy = waitTemplate("search_button.png", 0.88)
    if not sx then
        toast("🔁 Không thấy kính lúp – vuốt thêm lần nữa")
        swipeToExplore()
        sx, sy = waitTemplate("search_button.png", 0.88, 10)  -- chờ thêm ~4 s
        if not sx then
            toast("❌ Vẫn không tìm được kính lúp")
            return false
        end
    end

    -- 3. Mở ô search (tap 2 lần như trước)
    tap(sx, sy); usleep(700000)
    tap(sx, sy); usleep(700000)

    -- 4. Nhập username & nhấn Search
inputText(username); usleep(700000)   -- gõ
tap(sx, sy)                           -- nhấn nút Search
usleep(5000000)                       -- ⏳ đợi 5 giây cho kết quả load

-- 5. Tab “Người dùng” – chờ chắc chắn rồi mới tap
local ux, uy = waitTemplate("user_tab.png", 0.85, 15, 400000)  -- ~6 s tối đa
if not ux then
    toast("❌ Không thấy tab Người dùng – bỏ qua username này")
    return false
end
tap(ux, uy); usleep(1200000)
tap(ux, uy); usleep(1200000)


-- 6. Nhấn kết quả đầu tiên
tap(ux + 30, uy + 120); usleep(3000000)
return true

end

-- Nếu thấy follow_button → tap; ngược lại coi như đã follow
local function followIfNeeded()
    local x, y = findTemplate("follow_button.png", 0.90)
    if x then
        tap(x, y)
        toast("✅ Đã nhấn Follow")
        usleep(1500000)
    else
        toast("ℹ️ Không thấy nút Follow – coi như đã follow")
    end
end

----------------------------------------------------------------
-- MAIN
----------------------------------------------------------------
-- Đọc danh sách username
local usernames = {}
for line in io.lines(usernameFile) do
    if line ~= "" then table.insert(usernames, line) end
end
if #usernames == 0 then
    toast("❌ username.txt trống"); return
end

for _, username in ipairs(usernames) do
    toast("🔍 Xử lý: " .. username)

    -- Khởi động lại TikTok
    appKill(bundleID); usleep(2000000)
    appRun (bundleID); usleep(4000000)

    if openProfile(username) then
        followIfNeeded()
    end
end

toast("🎉 Hoàn tất danh sách")
