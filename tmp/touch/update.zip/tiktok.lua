function random(a,b)
    local rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    return rand 
end
function touchC(x, y, radius)
    local a = random(1, 9)
    local b = random(16000, 17000)
    -- Tạo tọa độ ngẫu nhiên trong hình tròn
    local angle = math.random() * 2 * math.pi       -- Góc ngẫu nhiên từ 0 đến 2π
    local r = radius * math.sqrt(math.random())     -- Bán kính ngẫu nhiên, căn bậc 2 để phân bố đều
    local offsetX = math.floor(r * math.cos(angle))
    local offsetY = math.floor(r * math.sin(angle))
    local randX = x + offsetX
    local randY = y + offsetY
    touchDown(a, randX, randY)
    usleep(b)
    touchUp(a, randX, randY)
end
function wait(time)
    usleep(time*1000000)
end
function touchrandom(x1,y1,x2,y2,time,number)
    for i=1,number,1 do
        local x=math.random(x1,x2)
        local y=math.random(y1,y2)
        touch(x,y)
        wait(time/number)
    end
end
appActivate("com.ss.iphone.ugc.tiktok.lite");
usleep(3000000)
openURL("snssdk473824://inbox")
usleep(3000000)
touchC(223,1278,4)
usleep(10000000)
touchC(374,1000,4)
usleep(10000000)
for i=1,5000,1 do
        touchC(374,1000,20)
        usleep(150000)
    end
--touchrandom(223,227,1266,1270,2,1)