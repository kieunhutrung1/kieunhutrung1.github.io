local app = require("libs/support") 
local imgPath      = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID     = "com.ss.iphone.ugc.Ame"
function reOpenTiktok()
    local orientation = frontMostAppOrientation();
    if orientation ~= bundleID then
        appRun(bundleID)
        usleep(10000000) 
    end
end
function paste(input)
	copyText(input)
	wait(1)
	findimgsandclick({"img/paste.png"},5)
end
function checkcick(time)
local startTime = os.time()
    while 1<2 do
        findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png"}, 2)
        if os.difftime(os.time(), startTime) > time then
            break
        end
    end
end 
function checkuid(time)
    local startTime = os.time()
    while true do
        openURL("snssdk1233://inbox")
        wait(1)
        waitAndClick("img/bt_profile.png", 20)
        checkcick(10)
        waitAndClick("img/bt_id.png", 10)
        local text = clipText()
        if text and text ~= "" then
            -- toast("UID: " .. text, 3)
            return text
        end
        if os.difftime(os.time(), startTime) > time then
            break
        end
    end
    return nil -- Trả về nil nếu hết thời gian mà không có UID
end
function getTDSJson(token)
    local curl = require("cURL")
    local json = require("json")
    local res = ""
    local c = curl.easy{
        url = "https://traodoisub.com/api/?fields=tiktok_follow&access_token=" .. token,
        writefunction = function(data)
            res = res .. data
            return true
        end
    }
    c:setopt_ssl_verifypeer(false)
    c:setopt_ssl_verifyhost(false)
    local ok, err = pcall(function() c:perform() end)
    c:close()

    if not ok then
        toast("❌ Lỗi: " .. tostring(err), 3)
        return nil
    end
    local result = json.decode(res)
    if result then
        toast("✅ Lấy JSON thành công", 2)
        return result  -- Trả về object JSON đầy đủ
    else
        toast("❌ Không phân tích được JSON", 3)
        return nil
    end
end
function cauhinhuid(token, username)
    local curl = require("cURL")
    local json = require("json")
    local res = ""

    local url = "https://traodoisub.com/api/?fields=tiktok_run&id=" .. username .. "&access_token=" .. token

    local c = curl.easy{
        url = url,
        writefunction = function(data)
            res = res .. data
            return true
        end
    }

    c:setopt_ssl_verifypeer(false)
    c:setopt_ssl_verifyhost(false)
    local ok, err = pcall(function() c:perform() end)
    c:close()

    if not ok then
        toast("❌ Lỗi cấu hình: " .. tostring(err), 3)
        return nil
    end

    local result = json.decode(res)
    if result and result.success == 200 then
        toast(result.data.msg .. "\n👤 " .. result.data.uniqueID, 4)
        return true
    else
        toast("❌ Cấu hình thất bại", 3)
        return false
    end
end
--reOpenTiktok()
--openURL("snssdk1233://user/@dg_princess.vogue")
--waitAndClick("img/follow_button.png",20)
--local check= waitImage("img/follow_check.png",20)
--if(check~=false) then
--toast("Đã follow thành công ",3)
--end
local token = "TDS0nI1IXZ2V2ciojIyVmdlNnIsISNwAjMpxWZ0F2YiojIyV2c1Jye"
copyText("")
local uid = checkuid(15)  -- chạy tối đa 15 giây
if uid then
    toast("UID: " .. uid, 3)
    cauhinhuid(token, uid)
    local data = getTDSJson(token)

    if data then
        openURL("snssdk1233://user/@" .. data.data[1].uniqueID)
        waitAndClick("img/follow_button.png", 20)
        local check = waitImage("img/follow_check.png", 20)
        if (check ~= false) then
            toast("Đã follow thành công ", 3)
        end
    end
end


execute("rm -r "..Debug)