local lfs = require("lfs")
function findBinaryValue(data, key)
        local pattern = key .. "%z/%z(.-)%z"
        return string.match(data, pattern)
    end
    function urlEncode(str)
    if str == nil or str == "" then 
        return ""
    end
    return (str:gsub("([^%w%-_.~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end))
end
function filewrite(path, content)
    local file, err = io.open(path, "w")
    if not file then
        toast("Không thể mở file để ghi: " .. err, 20)
        return
    end
    if content == nil or content == "" then
        toast("Không thể mở file "..path.." để ghi: Content rỗng", 20)
        return
    end
    file:write(content)
    file:close()
end
-- Lấy đường dẫn container của TikTok
local resultTiktokInfo = appInfo("com.ss.iphone.ugc.Ame")
local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "")


-- Đường dẫn đến file cookie
local cookiePath = basePath .. "/Library/Cookies/Cookies.binarycookies"

-- Mở file nhị phân
local file = io.open(cookiePath, "rb")
if not file then
    toast("❌ Không tìm thấy file Cookies.binarycookies"..cookiePath, 5)
    return
end

toast("✅ Đã mở được file Cookies", 2)
local data = file:read("*all")
file:close()
local pos = string.find(data, "sessionid")
    if not pos then
        toast("No find sessionid", 5)
        return
    end
-- Lấy sessionid (ít nhất 32 ký tự mới coi là hợp lệ)
    local tail = string.sub(data, pos + 9, pos + 100)
    local session_value = findBinaryValue(data, "sessionid")
	if not session_value then
		session_value = findBinaryValue(data, "sessionid_ss")
	end
local keys = {
        "odin_tt", "store-idc", "store-country-code", "store-country-code-src", "store-country-sign",
        "passport_csrf_token", "passport_csrf_token_default", "tt-target-idc", "tt-target-idc-sign",
        "multi_sids", "sid_guard", "uid_tt", "uid_tt_ss", "sid_tt",
        "sessionid_ss", "msToken"
    }

    local result = { ["sessionid"] = session_value }

    for _, key in ipairs(keys) do
        local val = findBinaryValue(data, key)
        if val then result[key] = val end
    end
    
    local parts = {}
    for k, v in pairs(result) do
        table.insert(parts, k .. "=" .. urlEncode(v))
    end
    local resultString = table.concat(parts, "; ")
    -- Gửi dữ liệu qua curl
    local query = ""
    for k, v in pairs(result) do
        query = query .. "&" .. k .. "=" .. v
    end
    filewrite(rootDir().."/cacheCookie.txt", resultString)
toast("",9)