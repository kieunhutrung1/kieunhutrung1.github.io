local app = require("libs/support") 
local lfs = require("lfs")
local imgPath      = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID     = "com.ss.iphone.ugc.Ame"
function autoTuongTac(countDay)    
    countDay = countDay or 7
    toast("Chạy tương tác tiktok ngày "..countDay)
    function reOpenTiktok()
        local orientation = frontMostAppOrientation();
        if orientation ~= bundleID then
            appRun(bundleID)
            usleep(15000000) 
        end
end
function timkiem()
            toast("Tìm kiếm",2)
            openURL("snssdk1233://search")
            waitrandom(3,5)
            findimgsandclick({"img/xsearch.png","img/search.png"}, 2)
            waitrandom(3,5)
            findimgsandclick({"img/bt_data_search.png"}, 2)
            waitrandom(3,5)
            tap(169,327)
            waitrandom(3,5)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)        
             findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png"}, 2)
            tap(65, 1280);
end
function swipe1()
touchDown(4, 234.01, 838.37);
usleep(83463.25);
touchMove(4, 232.99, 828.19);
usleep(16623.75);
touchMove(4, 232.99, 817.00);
usleep(16761.38);
touchMove(4, 234.01, 795.60);
usleep(16636.71);
touchMove(4, 236.07, 778.30);
usleep(16872.92);
touchMove(4, 238.12, 763.04);
usleep(16440.25);
touchMove(4, 240.18, 747.75);
usleep(16710.46);
touchMove(4, 243.26, 732.48);
usleep(16602.75);
touchMove(4, 246.33, 719.25);
usleep(16778.71);
touchMove(4, 249.41, 706.02);
usleep(16556.67);
touchMove(4, 253.52, 689.72);
usleep(16803.21);
touchMove(4, 256.60, 677.50);
usleep(16494.79);
touchMove(4, 259.68, 665.29);
usleep(16993.21);
touchMove(4, 262.76, 655.11);
usleep(16557.08);
touchMove(4, 263.77, 646.95);
usleep(16488.46);
touchMove(4, 265.83, 640.84);
usleep(16770.88);
touchMove(4, 266.85, 635.75);
usleep(16729.92);
touchMove(4, 267.88, 631.68);
usleep(16615.75);
touchMove(4, 268.91, 629.65);
usleep(16565.92);
touchMove(4, 269.94, 627.61);
usleep(16837.04);
touchMove(4, 270.96, 625.58);
usleep(16526.79);
touchMove(4, 270.96, 624.56);
usleep(16547.17);
touchMove(4, 270.96, 623.54);
usleep(66769.83);
touchMove(4, 271.99, 623.54);
usleep(16651.58);
touchMove(4, 273.02, 623.54);
usleep(16712.79);
touchUp(4, 275.07, 631.68);
end
function xemBinhLuan()
        if findimgs({"img/check_video_running.png"},2) then
            toast("Xem comment",2)
            tap(707, 760,2);
            waitrandom(3,5) 
            swipe1()
            waitrandom(1,2)
            swipe1()            
            waitrandom(1,2)
            swipe1()            
            waitrandom(1,2)
            swipe1()            
            waitrandom(1,2)
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)        
             findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png"}, 2)
            tap(65, 1280);
        end
    end
    function clickLike()
        if countDay > 6 then
            if findimgs({"img/check_video_running.png"},2) then
                toast("Like video",2)
                tap(707, 670)
            end
        end
    end

function luotvideo(time)
local startTime = os.time()
    while 1<2 do
        toast("Lướt video",2)
        local x=random(136,600)
        swipe(x,485,x,150,0.1)
        --tap(65, 1280);
        waitrandom(5,10)
        if os.difftime(os.time(), startTime) > time then
            break
        end
    end
end


function xemLive()
        if findimgs({"img/check_video_running.png"},2) then
            toast("Goto LIVE",2)
            tap(72, 83);
            usleep(math.random(15000000, 20000000))
            if countDay < 7 then
                swipe(426,496,475,165,0.1)
                usleep(math.random(30000000, 60000000))
            end
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)  
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png"}, 2)
            tap(65, 1280);
        end
end
    function rePost()
        if findimgs({"img/check_video_running.png"},2) then
            toast("Repost video",2)
            tap(697, 1029);
            usleep(2300167.83);
            tap(74, 1025);
            usleep(3102982.83);
            tap(404, 1229);
            usleep(5102982.83);
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)        
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png"}, 2)
            tap(65, 1280);
        end
    end
reOpenTiktok()
    openURL("snssdk1233://inbox")
    usleep(6000000)
    local r_tuongtac = math.random(2, 4)
    if countDay < 7 then
        r_tuongtac = math.random(10, 20)
    end
for i = 1, r_tuongtac do
        reOpenTiktok()
        openURL("snssdk1233://inbox")
        usleep(6000000)        
        findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png"}, 2)
        tap(65, 1280);
        usleep(1000000) 
        swipe(426,496,475,165,0.1)
        usleep(math.random(5000000, 8000000))
        clickLike()
        xemBinhLuan()
        timkiem()
        xemLive()
        local r = math.random(2, 4)
        for i = 1, r do                
            if findimgs({"img/check_video_running.png"},2) then
                swipe(426,496,475,165,0.1)
            else
                local orientation = frontMostAppOrientation();
                if orientation ~= bundleID then
                    appRun(bundleID)
                    usleep(15000000) 
                end
                openURL("snssdk1233://inbox")
                usleep(500000)
                tap(65, 1280);
                usleep(500000)
                tap(65, 1280);
            end
            luotvideo(math.random(120, 300))
            usleep(math.random(5000000, 8000000))            
            local randoo = math.random(1, 5)
            if randoo == 2 then
                clickLike()
            end
            if randoo == 3 then
                xemBinhLuan()
            end
            if randoo == 4 then
                clickLike()
                xemBinhLuan()
                xemLive()
            end
            if randoo == 4 then
                rePost()
            end
            usleep(math.random(2000000, 3000000))            
        end 
    end    
end

autoTuongTac(5)