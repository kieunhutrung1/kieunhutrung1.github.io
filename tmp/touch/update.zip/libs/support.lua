local lfs = require("lfs")
function tap(x, y, time)
    time = time or 1
    for i = 1, time do
        touchDown(4, x, y)
        usleep(97942.79)
        touchUp(4, x, y)
        usleep(107942.79)
    end
end

function swipe(x1, y1, x2, y2, duration)
    local steps = 30
    local sleepTime = duration / steps
    local dx = (x2 - x1) / steps
    local dy = (y2 - y1) / steps

    touchDown(0, x1, y1)
    usleep(16570.67);
    for i = 1, steps do
        local moveX = x1 + dx * i
        local moveY = y1 + dy * i
        touchMove(4, moveX, moveY)
        usleep(sleepTime * 1000000)
    end
    usleep(16570.08);
    touchUp(0, x2, y2)
end
function findimgs(imgs, wait, exact)
    exact = exact or 0.96
    local timenow2 = os.time()
    local i = wait
    repeat
        --toast("Wait " .. i, 1)
        i = i - 1
        for _, img in ipairs(imgs) do
            local result = findImage(img, 0, exact, nil, true)
            for _, v in pairs(result) do
                --toast("Found: "..img,5)
                execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
                return true
            end
        end
        usleep(1000000)
    until (os.difftime(os.time(), timenow2) > wait)
    execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
    return false
end
function findimgsandclick(imgs, wait, exact)
    exact = exact or 0.96
    local timenow2 = os.time()
    local i = wait
    repeat
        --toast("Wait " .. i, 1)
        i = i - 1
        for _, img in ipairs(imgs) do
            local result = findImage(img, 0, exact, nil, true)
            for _, v in pairs(result) do
                --toast("Found: "..img,5)
                local x = v[1]
                local y = v[2]
                touchDown(4, x, y)
                usleep(97942.79)
                touchUp(4, x, y)
                usleep(1000000)
                execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
                return true
            end
        end
        usleep(1000000)
    until (os.difftime(os.time(), timenow2) > wait)
    execute("rm -r /private/var/mobile/Library/AutoTouch/Scripts/Debug/*");
    return false
end
function trim(s)
    return s:match("^%s*(.-)%s*$")
end
function split(inputstr, sep)
    if sep == nil then
        sep = "%s"  -- tách theo khoảng trắng mặc định
    end
    local t = {}
    for str in string.gmatch(inputstr, "([^" .. sep .. "]+)") do
        table.insert(t, str)
    end
    return t
end
function quickGetString(url)
    local handle = io.popen('curl "'..url..'"')
    local result_cmd = handle:read("*a")
    local success, _, exitCode = handle:close()
    --toast(result_cmd, 2)
    return result_cmd
end
function unescape_unicode(str)
    return str:gsub("\\u(%x%x%x%x)", function(code)
        return utf8.char(tonumber(code, 16))
    end)
end
function filewrite(path, content)
    local file, err = io.open(path, "w")
    if not file then
        toast("Không thể mở file để ghi: " .. err, 20)
        return
    end
    if content == nil or content == "" then
        toast("Không thể mở file "..path.." để ghi: Content rỗng", 20)
        return
    end
    file:write(content)
    file:close()
end
function fileread(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*l")
        file:close()
        return content;
    end
    return ""
end
function ensure_dir(path)
    local attr = lfs.attributes(path)
    if not attr or attr.mode ~= "directory" then
        execute("mkdir -p " .. path)
    end
end
function closeAllApp()
    local function keyPress(keyType)
        keyDown(keyType);
        usleep(10000);
        keyUp(keyType);
    end
    keyPress(KEY_TYPE.HOME_BUTTON);
    keyPress(KEY_TYPE.HOME_BUTTON);
    -- Lặp qua nhiều app
    for i = 1, 20 do
        swipe(400, 1000, 400, 300, 0.2)
        usleep(500)
    end
    keyPress(KEY_TYPE.HOME_BUTTON);
end
function urlEncode(str)
    return (str:gsub("([^%w%-_.~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end))
end


function random(a,b)
    local rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    rand=math.random(a,b)
    return rand 
end
function tapC(x, y, radius)
    local a = random(1, 9)
    local b = random(16000, 17000)
    -- Tạo tọa độ ngẫu nhiên trong hình tròn
    local angle = math.random() * 2 * math.pi       -- Góc ngẫu nhiên từ 0 đến 2π
    local r = radius * math.sqrt(math.random())     -- Bán kính ngẫu nhiên, căn bậc 2 để phân bố đều
    local offsetX = math.floor(r * math.cos(angle))
    local offsetY = math.floor(r * math.sin(angle))
    local randX = x + offsetX
    local randY = y + offsetY
    touchDown(a, randX, randY)
    usleep(b)
    touchUp(a, randX, randY)
end
function wait(time)
    usleep(time*1000000)
end
function touchrandom(x1,y1,x2,y2,time,number)
    for i=1,number,1 do
        local x=math.random(x1,x2)
        local y=math.random(y1,y2)
        touch(x,y)
        wait(time/number)
    end
end
