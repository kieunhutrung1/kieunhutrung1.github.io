screenshot ("img/1");
screenshot ("img/follow_button1.png", {167, 547, 95, 28});