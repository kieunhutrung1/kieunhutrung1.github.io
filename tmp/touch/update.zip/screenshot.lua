screenshot ("img/screenshot1");
screenshot ("img/screenshot2.png", {26, 258, 30, 30});