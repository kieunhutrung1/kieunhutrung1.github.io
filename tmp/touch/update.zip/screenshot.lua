screenshot ("img/screenshot1");
screenshot ("img/bt_not_now1.png", {167, 866, 120, 28});