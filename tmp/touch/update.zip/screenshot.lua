screenshot ("img/1");
screenshot ("img/bt_privacy_close.png", {678, 764, 33, 33});